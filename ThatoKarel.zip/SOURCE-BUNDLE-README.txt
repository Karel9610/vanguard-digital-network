Vanguard Digital Network website source bundle

Includes the website artifact, shared API client workspace package, and workspace manifests/lockfile.
Installed dependencies and generated build output are excluded.
The source is preserved under its original workspace paths.
