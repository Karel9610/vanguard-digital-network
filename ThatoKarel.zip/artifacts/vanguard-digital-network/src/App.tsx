import { type FormEvent, type ReactNode } from 'react';
import { useEffect, useState } from 'react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { ErrorBoundary } from '@/components/error-boundary';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import NotFound from '@/pages/not-found';
import {
  ArrowDownRight,
  ArrowRight,
  Check,
  ChevronDown,
  Copy,
  Globe2,
  LayoutTemplate,
  Menu,
  MessageCircle,
  Plus,
  ShieldCheck,
  Smartphone,
  Sparkles,
  X,
} from 'lucide-react';
import {
  Route,
  Switch,
  useLocation,
  Router as WouterRouter,
} from 'wouter';

const queryClient = new QueryClient();
const BUSINESS_WHATSAPP_NUMBER = '27746579304';
const BUSINESS_WHATSAPP_DISPLAY = '074 657 9304';

const getWhatsAppUrl = (message?: string) => {
  const url = `https://wa.me/${BUSINESS_WHATSAPP_NUMBER}`;
  return message ? `${url}?text=${encodeURIComponent(message)}` : url;
};

function Home() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [draft, setDraft] = useState('');
  const [copyState, setCopyState] = useState<'idle' | 'copied' | 'error'>('idle');

  useEffect(() => {
    document.title = 'Vanguard Digital Network | Websites for North West Businesses';
    const description = document.querySelector('meta[name="description"]');
    if (description) {
      description.setAttribute(
        'content',
        'Professional websites for small and medium-sized businesses across North West Province, South Africa, from a partner connected to the local business community.',
      );
    }
  }, []);

  const closeMenu = () => setMenuOpen(false);
  const handleEnquiry = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const form = new FormData(event.currentTarget);
    const name = String(form.get('name') || '').trim();
    const business = String(form.get('business') || '').trim();
    const email = String(form.get('email') || '').trim();
    const details = String(form.get('details') || '').trim();
    setDraft(
      `Hello Vanguard Digital Network,\n\nI'm ${name}${business ? ` from ${business}` : ''}.\n\n${details}\n\nYou can reach me at ${email}.\n\nThanks,`,
    );
    setCopyState('idle');
  };
  const copyDraft = async () => {
    try {
      await navigator.clipboard.writeText(draft);
      setCopyState('copied');
    } catch {
      setCopyState('error');
    }
  };

  return (
    <div className="site-shell min-h-[100dvh]">
      <header className="relative z-20 border-b border-[#e9e5db] bg-[#f7f5ef]/95 backdrop-blur-sm">
        <div className="section-wrap flex h-[78px] items-center justify-between">
          <a className="flex items-center gap-3 no-underline" href="#top" aria-label="Vanguard Digital Network home" data-testid="link-home">
            <span className="flex h-[38px] w-[38px] items-center justify-center rounded-[12px] bg-[#21483d] text-[#f7f5ef]">
              <span className="font-display text-[19px] font-extrabold tracking-[-.08em]">V</span>
            </span>
            <span className="flex flex-col leading-tight">
              <span className="font-display text-[13px] font-extrabold tracking-[-.045em] text-[#21483d]">Vanguard</span>
              <span className="mt-[3px] text-[9px] font-semibold uppercase tracking-[.17em] text-[#758078]">Digital Network</span>
            </span>
          </a>
          <nav className="hidden items-center gap-9 text-[12px] font-semibold md:flex" aria-label="Main navigation">
            <a className="nav-link" href="#approach" data-testid="link-approach">How it works</a>
            <a className="nav-link" href="#what-you-get" data-testid="link-services">Why choose us</a>
            <a className="nav-link" href="#questions" data-testid="link-faq">Questions</a>
          </nav>
          <a className="btn btn-dark desktop-header-cta min-h-[43px] px-[19px] text-[12px]" href="#start" data-testid="link-start-project">
            Start a conversation <ArrowRight size={15} strokeWidth={1.8} />
          </a>
          <button
            type="button"
            className="flex h-10 w-10 items-center justify-center rounded-full border border-[#ddd9cf] text-[#21483d] md:hidden"
            aria-label={menuOpen ? 'Close navigation menu' : 'Open navigation menu'}
            aria-expanded={menuOpen}
            onClick={() => setMenuOpen(!menuOpen)}
            data-testid="button-mobile-menu"
          >
            {menuOpen ? <X size={19} /> : <Menu size={19} />}
          </button>
        </div>
        {menuOpen && (
          <nav className="mobile-menu absolute left-0 right-0 top-full border-b border-[#e9e5db] bg-[#f7f5ef] px-5 pb-5 pt-2 shadow-md md:hidden" aria-label="Mobile navigation">
            <a onClick={closeMenu} className="block border-b border-[#e6e1d7] py-3 text-sm font-semibold text-[#21483d]" href="#approach" data-testid="mobile-link-approach">How it works</a>
            <a onClick={closeMenu} className="block border-b border-[#e6e1d7] py-3 text-sm font-semibold text-[#21483d]" href="#what-you-get" data-testid="mobile-link-services">Why choose us</a>
            <a onClick={closeMenu} className="block py-3 text-sm font-semibold text-[#21483d]" href="#questions" data-testid="mobile-link-faq">Questions</a>
            <a onClick={closeMenu} className="btn btn-dark mt-2 w-full" href="#start" data-testid="mobile-link-start">Start a conversation <ArrowRight size={15} /></a>
          </nav>
        )}
      </header>

      <main id="top">
        <section className="relative bg-[#f7f5ef]">
          <div className="section-wrap grid min-h-[650px] items-center gap-10 py-16 md:grid-cols-[1.04fr_.96fr] md:gap-8 md:py-[88px]">
            <div className="reveal relative z-10">
              <span className="eyebrow">Website design for North West businesses</span>
              <h1 className="font-display mt-7 max-w-[590px] text-[clamp(3.3rem,6.4vw,5.65rem)] font-semibold leading-[.99] tracking-[-.075em] text-[#21483d]">
                Your work is good. <span className="text-[#c9795a]">Let’s make sure</span> your website is, too.
              </h1>
              <p className="mt-7 max-w-[480px] text-[16px] leading-[1.8] text-[#66746d]">
                Professional websites for small and medium-sized businesses across North West Province, made with a locally connected partner who takes time to understand your business.
              </p>
              <div className="mt-9 flex flex-wrap items-center gap-3">
                <a className="btn btn-dark" href="#start" data-testid="hero-link-start">Let’s talk about your website <ArrowRight size={16} /></a>
                <a className="arrow-link inline-flex min-h-[48px] items-center gap-2 px-3 text-[12px] font-bold text-[#21483d] no-underline" href="#approach" data-testid="hero-link-approach">See how it works <ArrowDownRight size={16} /></a>
              </div>
              <div className="mt-11 flex items-center gap-3 border-t border-[#e3dfd5] pt-5 text-[11px] font-medium text-[#778079]">
                <span className="flex h-7 w-7 items-center justify-center rounded-full bg-[#e8ece3] text-[#456558]"><Check size={14} /></span>
                Clear process <span className="mx-1 text-[#d3cec2]">/</span> Straightforward support <span className="mx-1 text-[#d3cec2]">/</span> Built around you
              </div>
            </div>

            <div className="reveal-late relative mx-auto w-full max-w-[555px] pb-5 pt-5 md:ml-auto">
              <div className="absolute -right-6 top-4 h-[380px] w-[380px] rounded-full border border-[#e3ded1] md:right-[-22px] md:top-[-12px]">
                <div className="hero-orbit absolute left-[43px] top-[38px] h-[300px] w-[300px] rounded-full border border-dashed border-[#d8d4c8]">
                  <span className="absolute -left-[5px] top-[112px] h-[10px] w-[10px] rounded-full bg-[#cd8061]" />
                </div>
              </div>
              <div className="relative rounded-[21px] border border-[#e3dfd5] bg-[#fffdf8] p-[11px] shadow-[0_28px_72px_rgba(37,66,55,.13)]">
                <div className="flex h-9 items-center gap-2 border-b border-[#eeece5] px-3">
                  <span className="h-[7px] w-[7px] rounded-full bg-[#dfb0a0]" />
                  <span className="h-[7px] w-[7px] rounded-full bg-[#e8d29a]" />
                  <span className="h-[7px] w-[7px] rounded-full bg-[#bdd0bc]" />
                  <span className="ml-3 h-[19px] flex-1 rounded-full bg-[#f2f1eb] px-3 pt-[3px] text-[8px] text-[#969a90]">yourbusiness.co</span>
                  <Globe2 size={12} className="mr-1 text-[#959c92]" />
                </div>
                <div className="relative min-h-[350px] overflow-hidden rounded-b-[13px] bg-[#eaece3] p-5 sm:p-7">
                  <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_76%_36%,rgba(204,181,141,.42),transparent_36%),linear-gradient(137deg,#e8e9df_0%,#dce5dc_52%,#e9e4d7_100%)]" />
                  <div className="relative z-[1] flex items-center justify-between">
                    <div className="font-display text-[11px] font-extrabold tracking-[-.04em] text-[#28493f]">THE GOOD THING</div>
                    <div className="hidden gap-4 text-[8px] font-semibold text-[#4e665b] sm:flex"><span>About</span><span>Services</span><span>Contact</span></div>
                    <div className="h-6 w-6 rounded-full border border-[#789084] sm:hidden" />
                  </div>
                  <div className="relative z-[1] mt-[52px] max-w-[230px] sm:mt-[62px]">
                    <span className="text-[8px] font-bold uppercase tracking-[.17em] text-[#667b6d]">Made with care, close to home</span>
                    <div className="font-display mt-3 text-[33px] font-semibold leading-[1.02] tracking-[-.07em] text-[#24463b] sm:text-[42px]">A little more<br />thoughtful.</div>
                    <p className="mt-3 max-w-[175px] text-[9px] leading-[1.7] text-[#617269]">Good work, a warm welcome, and a better way to get started.</p>
                    <div className="mt-4 flex h-[27px] w-[116px] items-center justify-center gap-2 rounded-full bg-[#284b40] text-[8px] font-bold text-[#f8f6ef]">Come on in <ArrowRight size={10} /></div>
                  </div>
                  <div className="absolute bottom-[-28px] right-[18px] h-[185px] w-[157px] rounded-t-[90px] bg-[linear-gradient(160deg,#b8a98a,#8c9981_57%,#697e6e)] sm:right-[34px] sm:h-[220px] sm:w-[185px]">
                    <div className="absolute left-[24px] top-[24px] h-[142px] w-[109px] rounded-t-[70px] border border-[#f3eee1]/40 bg-[linear-gradient(135deg,rgba(231,216,184,.72),rgba(126,150,126,.68))] sm:h-[170px] sm:w-[137px]" />
                    <div className="absolute bottom-[22px] left-[50%] h-[68px] w-[57px] -translate-x-1/2 rounded-t-[35px] bg-[#ead7bc] shadow-[0_5px_16px_rgba(46,58,44,.13)] sm:h-[84px] sm:w-[70px]" />
                  </div>
                  <div className="absolute bottom-5 left-5 z-[1] text-[8px] font-medium tracking-[.12em] text-[#63766b]">INDEPENDENT BY NATURE</div>
                </div>
              </div>
              <div className="float-card absolute -bottom-1 left-0 flex items-center gap-3 rounded-[14px] border border-[#e8e4da] bg-[#fffdf8] px-4 py-3 shadow-[0_12px_35px_rgba(38,65,56,.12)] sm:-left-7">
                <span className="flex h-9 w-9 items-center justify-center rounded-full bg-[#f1e1d7] text-[#b7644b]"><MessageCircle size={17} /></span>
                <span><span className="block text-[11px] font-bold text-[#28483e]">Easy to get in touch</span><span className="mt-1 block text-[9px] text-[#81877f]">Made for real conversations</span></span>
              </div>
            </div>
          </div>
          <div className="border-y border-[#e8e4da] bg-[#f2f0e8]">
            <div className="section-wrap flex flex-col gap-3 py-4 text-center sm:flex-row sm:items-center sm:justify-between sm:text-left">
              <span className="text-[10px] font-bold uppercase tracking-[.14em] text-[#718077]">The essentials, done thoughtfully</span>
              <div className="flex flex-wrap justify-center gap-x-7 gap-y-2 text-[11px] font-semibold text-[#456156] sm:justify-end">
                <span className="flex items-center gap-2"><Check size={13} className="text-[#c9795a]" /> A clear first impression</span>
                <span className="flex items-center gap-2"><Check size={13} className="text-[#c9795a]" /> Works beautifully on mobile</span>
                <span className="flex items-center gap-2"><Check size={13} className="text-[#c9795a]" /> Built to invite enquiries</span>
              </div>
            </div>
          </div>
        </section>

        <section id="approach" className="section-wrap grid gap-12 py-16 md:grid-cols-[.78fr_1.22fr] md:gap-20 md:py-[130px]">
          <div>
            <span className="eyebrow">A partner, not a hand-off</span>
            <h2 className="font-display mt-6 max-w-[410px] text-[clamp(2.4rem,4.3vw,3.8rem)] font-semibold leading-[1.04] tracking-[-.07em] text-[#21483d]">Good websites start with a good conversation.</h2>
            <p className="mt-6 max-w-[365px] text-[14px] leading-[1.8] text-[#6b7770]">No jargon, no off-the-shelf feel. First we get to know what you do and what your customers need. Then we make a plan that makes sense.</p>
            <a href="#start" className="arrow-link mt-7 inline-flex items-center gap-2 text-[12px] font-bold text-[#b76a50] no-underline" data-testid="link-approach-enquire">Talk through your ideas <ArrowRight size={15} /></a>
          </div>
          <div className="grid gap-0 border-t border-[#ddd9cf]">
            {[
              { n: '01', title: 'We get to know your business', body: 'What makes you different, who you want to reach, and what a useful website needs to do for you.' },
              { n: '02', title: 'We make a clear plan', body: 'A considered structure, visual direction, and messaging that helps people understand whether your business is right for them.' },
              { n: '03', title: 'We build it together', body: 'A responsive, considered website takes shape. You stay in the loop, with room to review and refine as we go.' },
              { n: '04', title: 'You know what comes next', body: 'We help get the essentials in place, then make sure you know what’s next and how to keep things current.' },
            ].map((step) => (
              <div key={step.n} className="grid grid-cols-[48px_1fr] gap-4 border-b border-[#ddd9cf] py-6 sm:grid-cols-[60px_1fr] sm:gap-6 sm:py-7">
                <span className="font-display pt-1 text-[12px] font-bold tracking-[.08em] text-[#ca795a]">{step.n}</span>
                <div><h3 className="font-display text-[17px] font-bold tracking-[-.04em] text-[#26483e]">{step.title}</h3><p className="mt-2 max-w-[500px] text-[13px] leading-[1.75] text-[#737c74]">{step.body}</p></div>
              </div>
            ))}
          </div>
        </section>

        <section id="what-you-get" className="bg-[#eaece4] py-14 md:py-[112px]">
          <div className="section-wrap">
            <div className="grid items-end gap-5 md:grid-cols-[1fr_.72fr] md:gap-14">
              <div><span className="eyebrow">Why choose Vanguard</span><h2 className="font-display mt-6 max-w-[600px] text-[clamp(2.5rem,4.7vw,4.15rem)] font-semibold leading-[1.02] tracking-[-.075em] text-[#21483d]">A website shaped around your business.</h2></div>
              <p className="max-w-[390px] pb-1 text-[14px] leading-[1.8] text-[#69776e]">Every project starts with your business, your customers, and the next step you want visitors to take.</p>
            </div>
            <div className="mt-12 grid border-l border-t border-[#d2d8ce] sm:grid-cols-2 lg:grid-cols-3">
              {[
                { icon: Globe2, title: 'Built for local business', body: 'Based in North West and connected to its local business community, we understand the needs of small and medium-sized businesses throughout the province.' },
                { icon: LayoutTemplate, title: 'Professional first impression', body: 'Give customers a modern, professional place to learn about your business and the services you offer.' },
                { icon: Smartphone, title: 'Mobile-friendly', body: 'Your website should work beautifully on phones, tablets, and computers.' },
                { icon: MessageCircle, title: 'Simple and clear', body: 'Make it easy for customers to understand what your business offers and how to get in touch.' },
                { icon: ShieldCheck, title: 'Built to grow', body: 'Create a digital foundation that can develop as your business grows.' },
                { icon: Sparkles, title: 'Personal service', body: 'Work directly with you to understand what your business needs—not a one-size-fits-all solution.' },
              ].map(({ icon: Icon, title, body }, i) => (
                <article key={title} className="group min-h-[238px] border-b border-r border-[#d2d8ce] bg-[#f4f3ed] p-7 transition-colors duration-200 hover:bg-[#fbfaf5] sm:p-8">
                  <div className="flex h-10 w-10 items-center justify-center rounded-[12px] bg-[#e4e9df] text-[#315b4d]"><Icon size={19} strokeWidth={1.7} /></div>
                  <span className="mt-7 block text-[9px] font-bold tracking-[.12em] text-[#c3795c]">0{i + 1}</span>
                  <h3 className="font-display mt-2 text-[17px] font-bold tracking-[-.04em] text-[#26483e]">{title}</h3>
                  <p className="mt-2 text-[12px] leading-[1.75] text-[#758078]">{body}</p>
                </article>
              ))}
            </div>
            <div className="mt-5 flex flex-col justify-between gap-4 rounded-[14px] border border-[#d4d9d0] bg-[#f4f3ed]/65 px-6 py-5 sm:flex-row sm:items-center">
              <div className="flex items-start gap-3"><Sparkles size={17} className="mt-0.5 shrink-0 text-[#c4795a]" /><p className="max-w-[710px] text-[12px] leading-[1.7] text-[#68766e]"><strong className="font-bold text-[#36584c]">Made to feel like you.</strong> The design, language, and details should reflect your business—not a template with your name dropped in.</p></div>
              <a href="#start" className="arrow-link inline-flex shrink-0 items-center gap-2 text-[11px] font-bold text-[#315b4d] no-underline" data-testid="link-services-enquire">Let’s talk <ArrowRight size={14} /></a>
            </div>
          </div>
        </section>

        <section className="relative overflow-hidden bg-[#21483d] py-16 text-[#f6f4ec] md:py-[115px]">
          <div className="texture absolute inset-0 opacity-30" />
          <div className="section-wrap relative grid items-center gap-10 md:grid-cols-[.96fr_1.04fr] md:gap-20">
            <div><span className="eyebrow !text-[#c5d1c7]">Keep it clear</span><h2 className="font-display mt-6 max-w-[500px] text-[clamp(2.55rem,4.7vw,4.25rem)] font-semibold leading-[1.02] tracking-[-.075em]">The internet’s busy. Your website doesn’t have to be.</h2><p className="mt-6 max-w-[420px] text-[14px] leading-[1.8] text-[#ced8cf]">In a crowded online space, a focused website gives your business a clear introduction and keeps useful information easy to find.</p></div>
            <div className="relative rounded-[18px] border border-[#537064] bg-[#2a5549] p-6 sm:p-8">
              <div className="flex items-center justify-between border-b border-[#496a5e] pb-4">
                <span className="text-[10px] font-bold uppercase tracking-[.16em] text-[#d4ddd5]">A good visit feels like this</span>
                <span className="flex h-7 w-7 items-center justify-center rounded-full bg-[#44695b] text-[#e8ede4]"><ArrowDownRight size={15} /></span>
              </div>
              <div className="space-y-0">
                {[
                  ['01', 'I understand what you do.'],
                  ['02', 'I can see why it might suit me.'],
                  ['03', 'I know exactly how to reach you.'],
                ].map(([number, text]) => <div key={number} className="flex items-center gap-4 border-b border-[#496a5e] py-5 last:border-0"><span className="text-[10px] font-bold tracking-[.13em] text-[#d38c70]">{number}</span><span className="font-display text-[16px] font-medium tracking-[-.025em] text-[#f3f2e9]">{text}</span><Check size={15} className="ml-auto text-[#c5d6c4]" /></div>)}
              </div>
              <div className="mt-4 flex items-center gap-2 text-[10px] text-[#c3d0c5]"><span className="h-1.5 w-1.5 rounded-full bg-[#d68a6b]" />Simple is a strength.</div>
            </div>
          </div>
        </section>

        <section className="section-wrap py-16 md:py-[118px]">
          <div className="grid gap-9 md:grid-cols-[.65fr_1.35fr] md:gap-20">
            <div><span className="eyebrow">A good fit</span><h2 className="font-display mt-6 max-w-[340px] text-[clamp(2.5rem,4vw,3.5rem)] font-semibold leading-[1.02] tracking-[-.07em] text-[#21483d]">Built around the people behind the business.</h2></div>
            <div className="pt-1">
              <p className="max-w-[690px] text-[19px] leading-[1.55] tracking-[-.025em] text-[#4f645a]">Vanguard Digital Network works with small and medium-sized businesses across North West, creating professional websites that reflect the people behind each business and make the next step clear for customers.</p>
              <div className="mt-8 grid gap-5 border-t border-[#e3dfd5] pt-6 sm:grid-cols-2">
                <div className="flex gap-3"><span className="mt-0.5 text-[#c87959]"><Check size={16} /></span><p className="text-[12px] leading-[1.75] text-[#717b73]"><strong className="text-[#315347]">You’re ready for a more considered website.</strong> Maybe the current one no longer reflects the business you’ve become.</p></div>
                <div className="flex gap-3"><span className="mt-0.5 text-[#c87959]"><Check size={16} /></span><p className="text-[12px] leading-[1.75] text-[#717b73]"><strong className="text-[#315347]">You want someone in your corner.</strong> Clear answers, a steady process, and a real person to work things through with.</p></div>
                <div className="flex gap-3"><span className="mt-0.5 text-[#c87959]"><Check size={16} /></span><p className="text-[12px] leading-[1.75] text-[#717b73]"><strong className="text-[#315347]">You’d rather keep it useful than complicated.</strong> A strong foundation, built for what customers actually need.</p></div>
                <div className="flex gap-3"><span className="mt-0.5 text-[#c87959]"><Check size={16} /></span><p className="text-[12px] leading-[1.75] text-[#717b73]"><strong className="text-[#315347]">You believe good work should look the part.</strong> Something distinctive, professional, and unmistakably yours.</p></div>
              </div>
            </div>
          </div>
        </section>

        <section id="questions" className="border-y border-[#e5e1d7] bg-[#f0eee7] py-14 md:py-[105px]">
          <div className="section-wrap grid gap-10 md:grid-cols-[.72fr_1.28fr] md:gap-20">
            <div><span className="eyebrow">Good to know</span><h2 className="font-display mt-6 max-w-[320px] text-[clamp(2.5rem,4vw,3.4rem)] font-semibold leading-[1.02] tracking-[-.07em] text-[#21483d]">A few things you might be wondering.</h2><p className="mt-5 max-w-[300px] text-[13px] leading-[1.8] text-[#737c74]">If there’s something else on your mind, that’s a good place to start our conversation.</p><a href="#start" className="arrow-link mt-5 inline-flex items-center gap-2 text-[12px] font-bold text-[#b76a50] no-underline" data-testid="link-faq-contact">Ask a question <ArrowRight size={15} /></a></div>
            <div className="border-t border-[#dcd8ce]">
              {[
                ['What kind of businesses do you work with?', 'Small and medium-sized businesses looking for a clear, professional way to present what they do online. Tell us a little about your business and we can talk about whether it’s a fit.'],
                ['I’m not sure what my website needs. Is that okay?', 'Absolutely. You don’t need to arrive with a brief or all the answers. We’ll talk through what you have in mind, what your customers need, and what would make a practical difference.'],
                ['What happens after I get in touch?', 'We’ll start with a conversation about your business and what you’re looking for. From there, we can work out sensible next steps together. There’s no commitment in asking a question.'],
                ['Do you work with businesses across North West?', 'Yes. Vanguard is based in North West and connected to the local business community, serving small and medium-sized businesses throughout the province.'],
                ['Can you help with an existing website?', 'Possibly. It depends on what you already have and what you’d like to change. A little context about your current site will help us understand what makes sense.'],
              ].map(([question, answer]) => (
                <details key={question} className="faq-item group border-b border-[#dcd8ce]">
                  <summary className="flex cursor-pointer list-none items-center justify-between gap-5 py-5 text-left [&::-webkit-details-marker]:hidden">
                    <span className="font-display text-[15px] font-bold tracking-[-.035em] text-[#2a4c40]">{question}</span>
                    <span className="faq-icon flex h-7 w-7 shrink-0 items-center justify-center rounded-full border border-[#ccd1c7] text-[#486657]"><Plus size={15} /></span>
                  </summary>
                  <p className="max-w-[570px] pb-5 pr-10 text-[12px] leading-[1.8] text-[#737b73]">{answer}</p>
                </details>
              ))}
            </div>
          </div>
        </section>

        <section id="start" className="relative overflow-hidden bg-[#dce6dc] py-16 md:py-[105px]">
          <div className="section-wrap grid gap-10 md:grid-cols-[.83fr_1.17fr] md:gap-16">
            <div className="pt-1">
              <span className="eyebrow">Start with a hello</span>
              <h2 className="font-display mt-6 max-w-[430px] text-[clamp(2.6rem,4.6vw,4.1rem)] font-semibold leading-[1.02] tracking-[-.075em] text-[#21483d]">Tell us a little about what you do.</h2>
              <p className="mt-6 max-w-[370px] text-[14px] leading-[1.8] text-[#63756a]">No polished brief needed. A few details are enough to get a useful conversation started.</p>
              <a href={getWhatsAppUrl()} target="_blank" rel="noopener noreferrer" className="group mt-8 flex items-center gap-3 rounded-[13px] border border-[#c8d5c9] bg-[#e8eee5] p-4 no-underline transition-colors hover:bg-[#edf2eb]">
                <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-[#f1e1d7] text-[#bd7054]"><MessageCircle size={17} /></span>
                <span className="min-w-0 flex-1"><span className="block text-[11px] font-bold text-[#36584c]">Prefer WhatsApp?</span><span className="mt-1 block text-[11px] leading-[1.6] text-[#687a6d]">Chat with Vanguard on {BUSINESS_WHATSAPP_DISPLAY}</span></span>
                <ArrowRight size={15} className="shrink-0 text-[#456558] transition-transform group-hover:translate-x-1" />
              </a>
              <p className="mt-3 max-w-[370px] text-[11px] leading-[1.7] text-[#687a6d]">Or prepare an enquiry below to review before continuing to WhatsApp.</p>
            </div>
            <div className="rounded-[18px] border border-[#e0e3d9] bg-[#f9f8f2] p-5 shadow-[0_15px_42px_rgba(41,73,59,.07)] sm:p-8">
              {!draft ? (
                <form className="space-y-4" onSubmit={handleEnquiry} data-testid="form-enquiry">
                  <div className="grid gap-4 sm:grid-cols-2">
                    <label className="block text-[11px] font-bold text-[#3b594d]">Your name<input className="field mt-2 text-[12px] font-normal" name="name" placeholder="How should we address you?" required data-testid="input-name" /></label>
                    <label className="block text-[11px] font-bold text-[#3b594d]">Business name <span className="font-normal text-[#8a9189]">(optional)</span><input className="field mt-2 text-[12px] font-normal" name="business" placeholder="Your business" data-testid="input-business" /></label>
                  </div>
                  <label className="block text-[11px] font-bold text-[#3b594d]">Email address<input className="field mt-2 text-[12px] font-normal" type="email" name="email" placeholder="you@example.com" required data-testid="input-email" /></label>
                  <label className="block text-[11px] font-bold text-[#3b594d]">What would you like help with?<textarea className="field mt-2 min-h-[112px] resize-y text-[12px] font-normal" name="details" placeholder="A little about your business and what you have in mind…" required data-testid="input-details" /></label>
                  <button className="btn btn-dark w-full sm:w-auto" type="submit" data-testid="button-prepare-message">Prepare my message <ArrowRight size={15} /></button>
                </form>
              ) : (
                <div data-testid="status-message-draft">
                  <div className="flex items-start justify-between gap-3">
                    <div><span className="eyebrow">Your message draft</span><h3 className="font-display mt-3 text-[21px] font-bold tracking-[-.04em] text-[#284b40]">Ready for you to take with you.</h3></div>
                    <button type="button" onClick={() => { setDraft(''); setCopyState('idle'); }} className="rounded-full p-2 text-[#718077] hover:bg-[#ecece4]" aria-label="Edit message" data-testid="button-edit-message"><X size={17} /></button>
                  </div>
                  <textarea readOnly value={draft} className="field mt-5 min-h-[188px] resize-y whitespace-pre-wrap text-[12px] leading-[1.8]" aria-label="Prepared enquiry message" data-testid="textarea-message-draft" />
                  <div className="mt-4 flex flex-wrap items-center gap-3">
                    <a href={getWhatsAppUrl(draft)} target="_blank" rel="noopener noreferrer" className="btn btn-dark" data-testid="link-send-whatsapp"><MessageCircle size={15} />Continue in WhatsApp <ArrowRight size={14} /></a>
                    <button type="button" className="btn btn-outline" onClick={copyDraft} data-testid="button-copy-message"><Copy size={15} />{copyState === 'copied' ? 'Copied to clipboard' : 'Copy message'}</button>
                    <button type="button" className="rounded-full px-3 py-2 text-[11px] font-bold text-[#526c62] hover:bg-[#ecece4]" onClick={() => { setDraft(''); setCopyState('idle'); }} data-testid="button-write-another">Start again</button>
                  </div>
                  {copyState === 'error' && <p className="mt-3 text-[11px] text-[#a54f3c]" role="status">Clipboard access isn’t available here. Select and copy the message above instead.</p>}
                  {copyState === 'copied' && <p className="mt-3 text-[11px] text-[#456c53]" role="status">Copied. Your message is still yours to send—continue in WhatsApp or paste it into your preferred app.</p>}
                  {copyState === 'idle' && <p className="mt-3 text-[11px] text-[#7a837a]">Your message stays on this device until you continue to WhatsApp or copy it elsewhere.</p>}
                </div>
              )}
            </div>
          </div>
        </section>
      </main>

      <footer className="bg-[#21483d] py-8 text-[#eef0e8]">
        <div className="section-wrap flex flex-col gap-6 sm:flex-row sm:items-center sm:justify-between">
          <a className="flex items-center gap-3 no-underline" href="#top" aria-label="Vanguard Digital Network home" data-testid="footer-link-home">
            <span className="flex h-[34px] w-[34px] items-center justify-center rounded-[11px] border border-[#607a6d] text-[#f3f0e7]"><span className="font-display text-[17px] font-extrabold tracking-[-.08em]">V</span></span>
            <span className="flex flex-col leading-tight"><span className="font-display text-[12px] font-extrabold tracking-[-.035em]">Vanguard</span><span className="mt-[3px] text-[8px] font-semibold uppercase tracking-[.16em] text-[#b7c5b9]">Digital Network</span></span>
          </a>
          <p className="text-[10px] text-[#c0cdc2]">A locally connected digital partner for small and medium-sized businesses across North West.</p>
          <a className="inline-flex items-center gap-2 text-[11px] font-bold text-[#f5f2e8] no-underline" href="#top" data-testid="footer-link-top">Back to top <ChevronDown className="rotate-180" size={14} /></a>
        </div>
        <div className="section-wrap mt-7 border-t border-[#49685b] pt-5 text-[9px] text-[#9fb3a4]">© {new Date().getFullYear()} Vanguard Digital Network</div>
      </footer>
    </div>
  );
}

function Router() {
  return (
    // Keep a shared shell (sidebar, navbar) outside the boundary so it
    // survives a page crash.
    <RoutedErrorBoundary>
      <Switch>
        <Route path="/" component={Home} />
        <Route component={NotFound} />
      </Switch>
    </RoutedErrorBoundary>
  );
}

function RoutedErrorBoundary({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  return <ErrorBoundary resetKey={location}>{children}</ErrorBoundary>;
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, '')}>
          <Router />
        </WouterRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
